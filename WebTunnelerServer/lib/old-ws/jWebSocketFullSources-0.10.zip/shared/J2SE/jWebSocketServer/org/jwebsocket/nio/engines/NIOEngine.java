/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.jwebsocket.nio.engines;

/**
 *
 * @author aschulze
 */
public class NIOEngine {

// solutions with code examples:
// http://forums.sun.com/thread.jspa?threadID=530825
// http://www.java2s.com/Code/Java/Network-Protocol/Nonblockserver.htm
// http://www.java2s.com/Code/Java/Network-Protocol/NIO-Socket.htm

// http://tim.oreilly.com/pub/a/onjava/2004/09/01/nio.html
// http://tim.oreilly.com/pub/a/onjava/2002/09/04/nio.html


// discussions:
// http://www.java-forum.org/netzwerkprogrammierung/96527-nio-sockets-architektur-problem.html

}
