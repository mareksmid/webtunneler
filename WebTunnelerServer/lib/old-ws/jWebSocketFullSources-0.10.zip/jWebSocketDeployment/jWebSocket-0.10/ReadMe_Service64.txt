jWebSocketService64.exe requires a working jWebSocketServer installation.
Please copy jWebSocketService64.exe to the /bin folder below your jWebSocket home folder and
use the jWebSocketInstallService64.bat to install the service in your 64bit Windows environment.
To start and stop the service please use the "services" dialog of Windows.
The jWebSocket home folder is specified by the JWEBSOCKET_HOME environment variable.