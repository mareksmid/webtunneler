The jWebSocketAppSvrDemo.war requires the jWebSockerServer-Bundle.jar
as well as the jWebSocketSamples.jar to be located in Tomcat's /lib folder.
You can use the jWebSocket.xml configuration file either in Tomcat's /conf
folder or in %JWEBSOCKET_HOME%/conf.
Please copy the jWebSocketAppSrvDemo.war file to Tomcat's /webapps folder 
to be auto-deployed or deploy it manually as described in the quick guide 
at http://jwebsocket.org.
