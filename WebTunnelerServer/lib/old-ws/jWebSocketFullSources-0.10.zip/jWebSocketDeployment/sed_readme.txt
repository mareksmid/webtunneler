// http://sed.sourceforge.net/
// http://gnuwin32.sourceforge.net/packages/sed.htm
// Usage: 
// SED.EXE "s/Old String/New String/g" < infile > outfile
